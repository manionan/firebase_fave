VERSION = '0.2.0'
from .fave import *